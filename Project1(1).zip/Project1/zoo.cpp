#include "zoo.h"
#include <fstream>
#include <iostream>
using namespace std;

static vector<string> split(const string& s, char sep) {
    vector<string> parts;
    string cur;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == sep) { parts.push_back(cur); cur = ""; }
        else cur += s[i];
    }
    parts.push_back(cur);
    return parts;
}

zoo::~zoo() {
    for (size_t i = 0; i < animals.size(); ++i) delete animals[i];
    animals.clear();
}

void zoo::addanimal(animal* a) {
    if (a == nullptr) return;
    animals.push_back(a);
    cout << "���ӳɹ� " << a->getname() << "(" << a->getcategory() << ")" << endl;
}

void zoo::showall() const {
    if (animals.empty()) { cout << "���޶���" << endl; return; }
    for (size_t i = 0; i < animals.size(); ++i) animals[i]->display();
}

animal* zoo::findbyid(const string& id) const {
    for (size_t i = 0; i < animals.size(); ++i)
        if (animals[i]->getid() == id) return animals[i];
    return nullptr;
}

bool zoo::removeanimal(const string& id) {
    for (size_t i = 0; i < animals.size(); ++i) {
        if (animals[i]->getid() == id) {
            delete animals[i];
            animals.erase(animals.begin() + i);
            return true;
        }
    }
    return false;
}

int zoo::count() const { return (int)animals.size(); }

void zoo::printbycategory() const {
    if (animals.empty()) { cout << "���޶���" << endl; return; }
    vector<string> categories;
    vector<vector<animal*>> groups;
    for (size_t i = 0; i < animals.size(); ++i) {
        string cat = animals[i]->getcategory();
        int pos = -1;
        for (size_t j = 0; j < categories.size(); ++j)
            if (categories[j] == cat) { pos = (int)j; break; }
        if (pos == -1) {
            categories.push_back(cat);
            vector<animal*> g;
            g.push_back(animals[i]);
            groups.push_back(g);
        }
        else {
            groups[pos].push_back(animals[i]);
        }
    }
    for (size_t i = 0; i < categories.size(); ++i) {
        cout << "\n��" << categories[i] << "���� " << groups[i].size() << " ֻ" << endl;
        for (size_t j = 0; j < groups[i].size(); ++j) groups[i][j]->display();
    }
}

bool zoo::updateanimal(const string& id, const string& newname) {
    animal* a = findbyid(id);
    if (a == nullptr) return false;
    a->setname(newname);
    return true;
}

bool zoo::feedanimal(const string& id, const string& date, double amount) {
    animal* a = findbyid(id);
    if (a == nullptr) return false;
    a->addfeedrecord(date, amount);
    return true;
}

bool zoo::checkhealth(const string& id, const string& date, const string& status, const string& note) {
    animal* a = findbyid(id);
    if (a == nullptr) return false;
    a->addhealthrecord(date, status, note);
    return true;
}

void zoo::showrecords(const string& id) const {
    for (size_t i = 0; i < animals.size(); ++i) {
        if (animals[i]->getid() == id) {
            animals[i]->showrecords();
            return;
        }
    }
    cout << "δ�ҵ���� " << id << " �Ķ���" << endl;
}

void zoo::save() const {
    ofstream fout("animals.txt");
    if (!fout) { cout << "���涯��ʧ��" << endl; return; }
    for (size_t i = 0; i < animals.size(); ++i) fout << animals[i]->saveline() << endl;
    fout.close();
    ofstream rout("records.txt");
    if (!rout) { cout << "�����¼ʧ��" << endl; return; }
    for (size_t i = 0; i < animals.size(); ++i) {
        vector<string> lines = animals[i]->saverecords();
        for (size_t j = 0; j < lines.size(); ++j) rout << lines[j] << endl;
    }
    rout.close();
    cout << "�ѱ��� " << animals.size() << " ֻ���Ｐ��¼" << endl;
}

void zoo::load() {
    ifstream fin("animals.txt");
    if (!fin) return;
    string line;
    while (getline(fin, line)) {
        if (line.empty()) continue;
        vector<string> p = split(line, '|');
        if (p.size() < 3) continue;
        string type = p[0], id = p[1], name = p[2];
        animal* a = nullptr;
        if (type == "eagle" && p.size() >= 4) a = new eagle(id, name, stod(p[3]));
        else if (type == "parrot" && p.size() >= 4) a = new parrot(id, name, stod(p[3]));
        else if (type == "lion") a = new lion(id, name);
        else if (type == "elephant") a = new elephant(id, name);
        if (a != nullptr) animals.push_back(a);
    }
    fin.close();
    ifstream rin("records.txt");
    if (!rin) return;
    while (getline(rin, line)) {
        if (line.empty()) continue;
        vector<string> p = split(line, '|');
        if (p.size() < 3) continue;
        string id = p[0], rtype = p[1];
        animal* a = findbyid(id);
        if (a == nullptr) continue;
        if (rtype == "feed" && p.size() >= 4) a->addfeedrecord(p[2], stod(p[3]));
        else if (rtype == "health" && p.size() >= 5) a->addhealthrecord(p[2], p[3], p[4]);
    }
    rin.close();
    cout << "�Ѵ��ļ����� " << animals.size() << " ֻ����" << endl;
}