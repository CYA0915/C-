#ifndef ZOO_H
#define ZOO_H
#include <vector>
#include <string>
#include "animal.h"
using namespace std;

class zoo {
private:
    vector<animal*> animals;
public:
    ~zoo();
    void addanimal(animal* a);
    void showall() const;
    animal* findbyid(const string& id) const;
    bool removeanimal(const string& id);
    int count() const;
    void printbycategory() const;
    bool updateanimal(const string& id, const string& newname);
    bool feedanimal(const string& id, const string& date, double amount);
    bool checkhealth(const string& id, const string& date, const string& status, const string& note);
    void showrecords(const string& id) const;
    void save() const;
    void load();
};

#endif#pragma once
